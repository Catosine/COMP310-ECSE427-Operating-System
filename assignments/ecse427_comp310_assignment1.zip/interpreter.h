// It handles user input
int decoder(int status, char *cmd);
int interpreter(char **tokenized_words);