ECSE 427 & COMP 310 Assignment 2
Winter 2020

# Author
Pengnan Fan 260768510

# Dev Env
This assignment is finished on mimi.cs.mcgill.ca

# Structure of This Folder
ecse427_comp310_assignment2_pengnan_260768510
    - inc
        ~ cpu.h
        ~ interpreter.h
        ~ kernel.h
        ~ pcb.h
        ~ ram.h
        ~ shellmemory.h
    - src
        ~ cpu.c
        ~ interpreter.c
        ~ kernel.c
        ~ pcb.c
        ~ ram.c
        ~ shell.c
        ~ shellmemory.c
    - makefile
    - mykernel
    - README.txt
    - script1.txt
    - script2.txt
    - script3.txt
    - testfile

# Makefile
This assignment contains a makefile which support:
- make build: compile the project to generate ./mykernel
- make clean: remove all object files *.o
NOTE: Please use the makefile to compile this assignment.