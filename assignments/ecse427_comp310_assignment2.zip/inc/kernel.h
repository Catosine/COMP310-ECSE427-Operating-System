char **parse(char *cmd);
int shellUI(int argc, char **argv);
int myinit(char *filename);
int scheduler();
int clearReadyQueue();