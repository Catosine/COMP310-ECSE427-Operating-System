#include "kernel.h"

// main function for HarmonyOS
int main(int argc, char **argv)
{
    return shellUI(argc, argv);
}
