ECSE 427 & COMP 310 Assignment 1
Winter 2020

# Dev Env
This assignment is finished on mimi.cs.mcgill.ca

# Makefile
This assignment contains a makefile which support:
- make mysh: compile the project to generate ./mysh
- make test: run testfile.txt at the same dir with ./mysh
- make clean: remove all compiled file (*.o, ./mysh)

# Notes on command
- This shell is implemented to support multi-value set:
    # store "STR1 STR2 STR3" to VAR
    set VAR STR1\ STR2\ STR3
    
    # store "STR1" to VAR
    set VAR STR1 STR2 STR3

