// It handles user input
int parseInput(char *cmd);
int decoder(int status, char *cmd);